class Citation {
  constructor() {
      this.currentIndex1 = 0;
      this.currentIndex2 = 0;
      this.currentIndex3 = 0;

      this.rangeSelector = document.getElementById("citation");
      this.rangeActive = document.querySelector(".js-citationValue");
      this.sentenceWrapper = document.getElementById("citationRange");

      this.wordsSelection = document.querySelector(".words__wrapper");
      this.citationSelector = document.querySelector(".citation__choice");

      this.rickContent = document.querySelectorAll(".js-elementRick");
      this.mortyContent = document.querySelectorAll(".js-elementMorty");

      this.morty = document.getElementById("profilMorty");
      this.rick = document.getElementById("profilRick");

      this.citationStart = document.getElementById("citationStart");
      this.citationMiddle = document.getElementById("citationMiddle");
      this.citationEnd = document.getElementById("citationEnd");

      ////                  ////
      //  Répliques de Rick  //
      ////                ////

      this.sentenceStartRick = ['Hey ', 'Wooooooo ', "BBBuuuurp, ", "Wubadubaleluba ", "Oh merde, ", "Mais non, ", "C'est pas moi ", "Mais qu'est-ce que tu fabriques, "];

      this.sentenceMiddleRick = ["non, ne fais pas ça", "t'es beaucoup trop con morty", "tu vas finir comme ton père", "en réalité tu as été adopté", "si tu continue comme ça", "n'hésites pas à pas hésiter", "bon sang, regarde"];

      this.sentenceEndRick = [" il faut que tu m'oublis maintenant.", " je vais allez couler un bronze.", " raaah mais quel con !", " bordel ! Tu m'as tiré dessus !", " ne t'aventure jamais sur ce sujet...", " c'est comme ça, c'est tout.", " tu veux avoir l'impression d'être important !"];


      ////                   ////
      //  Répliques de Morty  //
      ////                 ////

      this.sentenceStartMorty = ['Dis moi Rick... ', 'Trop cool, ', "Super ça, ", "Tu penses que ", "Tu ne comprend pas, ", "Dis moi que c'est une blague ", "Mon bras me fait mal, ", "Comme d'habitude, "];

      this.sentenceMiddleMorty = ["mes parents vont me tuer", "je sent que mes jambes me lache", "c'est normal que je vois double ?", "mon père est un conard", "on pourrait pas partir sur une planète remplis de fille ?", "je peux quand même conduire le vaisseau ?", "ces gens n'ont pas l'air de nous apprécier..."];

      this.sentenceEndMorty = [" je préfère m'enfuir !", " et le pire, c'est que je sais que ce n'est pas normal", " putain, je suis qu'un gamin !", " qu'est-ce qui ne tourne pas rond chez toi Rick ?", " je vais mourir je pense", " la prochaine fois, je choisis !", " je sent quelque chose qui bouge dans mon ventre..."];

      this.bindEvents();
  }
  bindEvents() {

      ////                   ////
      //  Sélection de Morty  //
      ////                 ////

    this.morty.addEventListener("click", () => {

      // Réinitialise les phrases
      this.refreshWords(this.citationStart, this.citationMiddle, this.citationEnd);

      // Cache le contenu de Rick
      this.rickContent.forEach(function(index){
        index.classList.toggle("js-hidden");
      });

      // Affiche la séléction de mot et séléction de phrase
      this.hiddenFunction(this.wordsSelection);
      this.hiddenFunction(this.citationSelector);

      document.getElementById("buttonOne").addEventListener("click", () =>{
        this.currentIndex1 = this.showNextWords(this.currentIndex1, this.citationStart, this.sentenceStartMorty);
      });
  
      document.getElementById("buttonTwo").addEventListener("click", () =>{
        this.currentIndex2 = this.showNextWords(this.currentIndex2, this.citationMiddle, this.sentenceMiddleMorty);
      });
  
      document.getElementById("buttonThree").addEventListener("click", () =>{
        this.currentIndex3 = this.showNextWords(this.currentIndex3, this.citationEnd, this.sentenceEndMorty);
      });
  
      document.getElementById("buttonRandom").addEventListener("click", () => {
        this.currentIndex1 = this.randomWords(this.citationStart, this.sentenceStartMorty);
        this.currentIndex2 = this.randomWords(this.citationMiddle, this.sentenceMiddleMorty);
        this.currentIndex3 = this.randomWords(this.citationEnd, this.sentenceEndMorty);
      });
    });


      ////                   ////
      //  Sélection de Rick   //
      ////                 ////

    this.rick.addEventListener("click", () => {

      // Réinitialise les phrases
      this.refreshWords(this.citationStart, this.citationMiddle, this.citationEnd);

      // Cache le copntenu de Morty
      this.mortyContent.forEach(function(index){
        index.classList.toggle("js-hidden");
      });

      // Affiche la séléction de mot et séléction de phrase
      this.hiddenFunction(this.wordsSelection);
      this.hiddenFunction(this.citationSelector);

      document.getElementById("buttonOne").addEventListener("click", () =>{
        this.currentIndex1 = this.showNextWords(this.currentIndex1, this.citationStart, this.sentenceStartRick);
      });
  
      document.getElementById("buttonTwo").addEventListener("click", () =>{
        this.currentIndex2 = this.showNextWords(this.currentIndex2, this.citationMiddle, this.sentenceMiddleRick);
      });
  
      document.getElementById("buttonThree").addEventListener("click", () =>{
        this.currentIndex3 = this.showNextWords(this.currentIndex3, this.citationEnd, this.sentenceEndRick);
      });
  
      document.getElementById("buttonRandom").addEventListener("click", () => {
        this.currentIndex1 = this.randomWords(this.citationStart, this.sentenceStartRick);
        this.currentIndex2 = this.randomWords(this.citationMiddle, this.sentenceMiddleRick);
        this.currentIndex3 = this.randomWords(this.citationEnd, this.sentenceEndRick);
      });
    });

    this.rangeSelector.addEventListener("change", () => {
      var currentSentenceNumber = this.sentenceWrapper.childElementCount;
      var value = Math.floor(this.rangeSelector.value);
      this.rangeActive.innerText = value;
      
      while (value < currentSentenceNumber) {
        // supprimer des phrases
        this.sentenceWrapper.removeChild(this.sentenceWrapper.lastChild);
        --currentSentenceNumber;
      }

      while (value > currentSentenceNumber) {
        // Ajoute des phrases
        var $p = document.createElement("p");
        $p.classList.add("citation__sentence");
        $p.innerText = "toto";
        this.sentenceWrapper.appendChild($p);
        ++currentSentenceNumber;
      }
    });
  }

  showNextWords(index, word, phrase) {
    ++index;
    if (index > phrase.length - 1) {
      index = 0;
    }
    word.innerText = phrase[index];
    return index;
  }

  randomWords(word, phrase) {
    let tips = phrase; 
    let picked = Math.floor(Math.random() * tips.length);
    word.innerText = tips[picked];
    return picked;
  };

  refreshWords(element1, element2, element3) {
    let newSentence = "...";
    element1.innerText = newSentence;
    element2.innerText = newSentence;
    element3.innerText = newSentence;
  }

  hiddenFunction(zone) {
    zone.classList.toggle("js-hidden");
  };
}
new Citation();