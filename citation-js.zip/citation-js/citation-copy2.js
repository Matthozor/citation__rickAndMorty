class Citation {
    constructor() {
        this.currentIndex1 = 0;
        this.currentIndex2 = 0;
        this.currentIndex3 = 0;
  
        this.wordsSelection = document.querySelector(".words__wrapper");
  
        this.rickContent = document.querySelectorAll(".js-elementRick");
        this.mortyContent = document.querySelectorAll(".js-elementMorty");
  
  
        this.nameMorty = document.getElementById("buttonMorty");
        this.morty = document.getElementById("profilMorty");
        this.rick = document.getElementById("profilRick");
  
        this.citationStart = document.getElementById("citationStart");
        this.citationMiddle = document.getElementById("citationMiddle");
        this.citationEnd = document.getElementById("citationEnd");
  
  
        ////                  ////
        //  Répliques de Rick  //
        ////                ////
  
        this.sentenceStartRick = ['Hey ', 'Wooooooo ', "BBBuuuurp, ", "Wubadubaleluba ", "Oh merde, ", "Mais non, ", "C'est pas moi ", "Mais qu'est-ce que tu fabriques, "];
  
        this.sentenceMiddleRick = ["non, ne fais pas ça", "t'es beaucoup trop con morty", "tu vas finir comme ton père", "en réalité tu as été adopté", "si tu continue comme ça", "n'hésites pas à pas hésiter", "bon sang, regarde"];
  
        this.sentenceEndRick = [" il faut que tu m'oublis maintenant.", " je vais allez couler un bronze.", " raaah mais quel con !", " bordel ! Tu m'as tiré dessus !", " ne t'aventure jamais sur ce sujet...", " c'est comme ça, c'est tout.", " tu veux avoir l'impression d'être important !"];
  
  
        ////                   ////
        //  Répliques de Morty  //
        ////                 ////
  
        this.sentenceStartMorty = ['Dis moi Rick... ', 'Trop cool, ', "Super ça, ", "Tu penses que ", "Tu ne comprend pas, ", "Dis moi que c'est une blague ", "Mon bras me fait mal, ", "Comme d'habitude, "];
  
        this.sentenceMiddleMorty = ["mes parents vont me tuer", "je sent que mes jambes me lache", "c'est normal que je vois double ?", "mon père est un conard", "on pourrait pas partir sur une planète remplis de fille ?", "je peux quand même conduire le vaisseau ?", "ces gens n'ont pas l'air de nous apprécier..."];
  
        this.sentenceEndMorty = [" je préfère m'enfuir !", " et le pire, c'est que je sais que ce n'est pas normal", " putain, je suis qu'un gamin !", " qu'est-ce qui ne tourne pas rond chez toi Rick ?", " je vais mourir je pense", " la prochaine fois, je choisis !", " je sent quelque chose qui bouge dans mon ventre..."];
  
        this.bindEvents();
    }
    bindEvents() {
      // ton listener au click
  
  
  
        ////                   ////
        //  Sélection de Morty  //
        ////                 ////
  
      this.morty.addEventListener("click", () => {
  
        // Cache le contenu de Rick
        this.rickContent.forEach(function(index){
          index.classList.toggle("js-hidden");
        });
  
        // Affiche la séléction de mot
        this.hiddenFunction(this.wordsSelection);
  
        document.getElementById("buttonOne").addEventListener("click", () =>{
          this.currentIndex1 = this.showNextWords(this.currentIndex1, this.citationStart, this.sentenceStartMorty);
        });
    
        document.getElementById("buttonTwo").addEventListener("click", () =>{
          this.currentIndex2 = this.showNextWords(this.currentIndex2, this.citationMiddle, this.sentenceMiddleMorty);
        });
    
        document.getElementById("buttonThree").addEventListener("click", () =>{
          this.currentIndex3 = this.showNextWords(this.currentIndex3, this.citationEnd, this.sentenceEndMorty);
        });
    
        document.getElementById("buttonRandom").addEventListener("click", () => {
          this.currentIndex1 = this.randomWord(this.citationStart, this.sentenceStartMorty);
          this.currentIndex2 = this.randomWord(this.citationMiddle, this.sentenceMiddleMorty);
          this.currentIndex3 = this.randomWord(this.citationEnd, this.sentenceEndMorty);
        });
      });
  
  
        ////                   ////
        //  Sélection de Rick   //
        ////                 ////
  
      this.rick.addEventListener("click", () => {
  
        // Cache le copntenu de Morty
        this.mortyContent.forEach(function(index){
          index.classList.toggle("js-hidden");
        });
  
        // Affiche la séléction de mot
        this.hiddenFunction(this.wordsSelection);
  
        document.getElementById("buttonOne").addEventListener("click", () =>{
          this.currentIndex1 = this.showNextWords(this.currentIndex1, this.citationStart, this.sentenceStartRick);
        });
    
        document.getElementById("buttonTwo").addEventListener("click", () =>{
          this.currentIndex2 = this.showNextWords(this.currentIndex2, this.citationMiddle, this.sentenceMiddleRick);
        });
    
        document.getElementById("buttonThree").addEventListener("click", () =>{
          this.currentIndex3 = this.showNextWords(this.currentIndex3, this.citationEnd, this.sentenceEndRick);
        });
    
        document.getElementById("buttonRandom").addEventListener("click", () => {
          this.currentIndex1 = this.randomWord(this.citationStart, this.sentenceStartRick);
          this.currentIndex2 = this.randomWord(this.citationMiddle, this.sentenceMiddleRick);
          this.currentIndex3 = this.randomWord(this.citationEnd, this.sentenceEndRick);
        });
      });
    }
  
    showNextWords(index, word, phrase) {
      index++;
      if (index > phrase.length - 1) {
        index = 0;
      }
      word.innerText = phrase[index];
      return index;
    }
  
    randomWord(word, phrase) {
      let tips = phrase; 
      let picked = Math.floor(Math.random() * tips.length);
      word.innerText = tips[picked];
      return picked;
    };
  
    hiddenFunction(zone) {
      zone.classList.toggle("js-hidden");
    }
  }
  new Citation();