class Citation {
  constructor() {
      this.currentIndex1 = 0;
      this.currentIndex2 = 0;
      this.currentIndex3 = 0;

      this.wordOne = document.getElementById("wordOne");
      this.wordTwo = document.getElementById("wordTwo");
      this.wordThree = document.getElementById("wordThree");

      this.phraseDebut = ['Hey ', 'Wooooooo ', "BBBuuuurp ! ", "Wubadubaleluba ", "Oh merde! ", "Mais non, ", "C'est pas moi ", "F**k off "];

      this.phraseMilieu = ["ne me touche pas,", "t'es beaucoup trop con morty", "ton père est enfaite une tortue", "en réalité tu as été adopté", "si tu continue comme ça", "n'hésites pas à pas hésiter", "bon sang, regarde"];

      this.phraseFin = [" il faut que tu m'oublis maintenant.", " je vais allez couler un bronze.", " raaah mais quel con !", " borderl ! tu m'as tiré dessus !", " ne t'aventure jamais sur ce sujet...", " c'est comme ça, c'est tout.", " tu vas finir aussi abruti que l'enveloppe corporelle qui te serts de père"];

      this.bindEvents();
  }
  bindEvents() {
    // ton listener au click
    document.getElementById("buttonOne").addEventListener("click", () =>{
      this.currentIndex1 = this.showNextWords(this.currentIndex1, this.wordOne, this.phraseDebut);
    });

    document.getElementById("buttonTwo").addEventListener("click", () =>{
      this.currentIndex2 = this.showNextWords(this.currentIndex2, this.wordTwo, this.phraseMilieu);
    });

    document.getElementById("buttonThree").addEventListener("click", () =>{
      this.currentIndex3 = this.showNextWords(this.currentIndex3, this.wordThree, this.phraseFin);
    });
  }

  showNextWords(index, word, phrase) {
    index++;
    if (index > phrase.length - 1) {
      index = 0;
    }
    word.innerText = phrase[index];
    return index;
  }
}
new Citation();